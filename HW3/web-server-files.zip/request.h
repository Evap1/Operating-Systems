#ifndef __REQUEST_H__

// handle a request
void requestHandle(int fd);

//  Returns True/False if realtime event
bool getRequestMetaData(int fd)

#endif
